To build Android version, Please execute the script : 
../../../build/android/jni/gpac_build_android <PATH_TO_ANDROID_NDK>
